import streamlit as st
import mlflow
import mlflow.sklearn
import joblib
import os

# Set MLflow tracking URI to the local 'mlruns' directory
mlflow.set_tracking_uri("file:./mlruns")

# Load the latest run ID from the file
with open('latest_run_id.txt', 'r') as f:
    run_id = f.read().strip()

print(f"Using run ID: {run_id}")

# Load the model, vectorizer, and scaler from MLflow
model_uri = f"runs:/{run_id}/random_forest_model"
vectorizer_path = mlflow.artifacts.download_artifacts(run_id=run_id, artifact_path="preprocessors/tfidf_vectorizer.joblib")
scaler_path = mlflow.artifacts.download_artifacts(run_id=run_id, artifact_path="preprocessors/standard_scaler.joblib")

try:
    model = mlflow.sklearn.load_model(model_uri)
    print(f"Model loaded successfully from: {model_uri}")
except Exception as e:
    print(f"Error loading model: {str(e)}")
    st.error("Error loading the model. Please check the logs and ensure the model was properly trained and logged.")
    st.stop()

vectorizer = joblib.load(vectorizer_path)
scaler = joblib.load(scaler_path)

# Streamlit app
st.title("Sentiment Analysis App")
st.write("Enter your text below to analyze its sentiment.")

# Input text
user_input = st.text_area("Text Input")

if st.button("Predict"):
    if user_input:
        try:
            # Vectorize the input text
            input_vectorized = vectorizer.transform([user_input])
            input_scaled = scaler.transform(input_vectorized)
            
            # Predict the sentiment
            prediction = model.predict(input_scaled)
            
            # Display the result
            sentiment = "Positive" if prediction[0] == 2 else ("Neutral" if prediction[0] == 1 else "Negative")
            st.write(f"Predicted Sentiment: {sentiment}")
        except Exception as e:
            st.error(f"An error occurred during prediction: {str(e)}")
    else:
        st.write("Please enter some text to analyze.")