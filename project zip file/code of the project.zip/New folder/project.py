

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix


train_data = pd.read_csv('/content/cleaned_train.csv', encoding='ISO-8859-1')
test_data = pd.read_csv('/content/cleaned_test.csv', encoding='ISO-8859-1')


print("Columns in training data:", train_data.columns)


target_column = 'sentiment'

train_data = train_data.dropna(subset=['cleaned_text', target_column])
if target_column not in train_data.columns:
    raise KeyError(f"The column '{target_column}' does not exist in the training data.")

plt.figure(figsize=(8, 5))
train_data[target_column].value_counts().plot(kind='bar', color='skyblue', alpha=0.7)
plt.title('Class Distribution in Training Data')
plt.xlabel('Sentiment Class')
plt.ylabel('Frequency')
plt.xticks(rotation=0)
plt.show()

train_data['text_length'] = train_data['cleaned_text'].apply(len)

plt.figure(figsize=(8, 5))
plt.hist(train_data['text_length'], bins=30, color='blue', alpha=0.7)
plt.title('Distribution of Cleaned Text Lengths')
plt.xlabel('Length of Text')
plt.ylabel('Frequency')
plt.show()

X = train_data['cleaned_text']
y = train_data[target_column]
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)
vectorizer = TfidfVectorizer(max_features=5000)
X_train_tfidf = vectorizer.fit_transform(X_train)
X_val_tfidf = vectorizer.transform(X_val)

log_reg = LogisticRegression()
log_reg.fit(X_train_tfidf, y_train)

y_val_pred_log_reg = log_reg.predict(X_val_tfidf)
print("Logistic Regression Model Performance:")
print(classification_report(y_val, y_val_pred_log_reg))

rf_model = RandomForestClassifier()
rf_model.fit(X_train_tfidf, y_train)

y_val_pred_rf = rf_model.predict(X_val_tfidf)
print("Random Forest Model Performance:")
print(classification_report(y_val, y_val_pred_rf))

plt.figure(figsize=(10, 6))
conf_matrix = confusion_matrix(y_val, y_val_pred_rf)
plt.imshow(conf_matrix, interpolation='nearest', cmap=plt.cm.Blues)
plt.title('Confusion Matrix for Random Forest Model')
plt.colorbar()
tick_marks = np.arange(len(np.unique(y)))
plt.xticks(tick_marks, np.unique(y))
plt.yticks(tick_marks, np.unique(y))

thresh = conf_matrix.max() / 2.
for i, j in np.ndindex(conf_matrix.shape):
    plt.text(j, i, format(conf_matrix[i, j], 'd'),
             horizontalalignment="center",
             color="white" if conf_matrix[i, j] > thresh else "black")

plt.ylabel('True label')
plt.xlabel('Predicted label')
plt.show()
